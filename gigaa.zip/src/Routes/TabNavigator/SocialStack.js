import React from 'react';
import {createStackNavigator} from '@react-navigation/stack';
import Friends from '../../screens/Friends/Friends.screen';
import Social from '../../screens/Social/Social.screen';
import Profile from '../../screens/Profile/Profile.screen';
import Requests from '../../screens/Requests/Requests.screen';
import Search from '../../screens/Search/Search.screen';
import CreateGig from '../../screens/CreateGig/CreateGig.screen';
import EditGig from '../../screens/EditGig/EditGig.screen';
import GigDetail from '../../screens/GigDetail/GigDetail.screen';
import GigParticipants from '../../screens/GigParticipants/GigParticipants.screen';
const Stack = createStackNavigator();
export default function Routes({}) {
  return (
    <Stack.Navigator initialRouteName={'Social'} headerMode="none">
      <Stack.Screen name="Social" component={Social} />
      <Stack.Screen name="Friends" component={Friends} />
      <Stack.Screen name="Requests" component={Requests} />
      <Stack.Screen name="Profile" component={Profile} />
      <Stack.Screen name="Search" component={Search} />
      <Stack.Screen name="CreateGig" component={CreateGig} />
      <Stack.Screen name="GigDetail" component={GigDetail} />
      <Stack.Screen name="EditGig" component={EditGig} />
      <Stack.Screen name="GigParticipants" component={GigParticipants} />
    </Stack.Navigator>
  );
}
