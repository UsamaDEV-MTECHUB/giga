import React from 'react';
import {createStackNavigator} from '@react-navigation/stack';
import ProviderTab from './Tab';
import WeatherDetail from '../../screens/WeatherDetail/WeatherDetail.screen';
const Stack = createStackNavigator();
export default function Routes({}) {
  return (
    <Stack.Navigator initialRouteName={'Dashboard'} headerMode="none">
      <Stack.Screen name="Dashboard" component={ProviderTab} />
      <Stack.Screen name="Home" component={ProviderTab} />
      <Stack.Screen name="Wallet" component={ProviderTab} />
      <Stack.Screen name="Message" component={ProviderTab} />
      <Stack.Screen name="Social" component={ProviderTab} />
      <Stack.Screen name="WeatherDetail" component={WeatherDetail} />
    </Stack.Navigator>
  );
}
