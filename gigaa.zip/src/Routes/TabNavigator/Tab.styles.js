import {StyleSheet, Platform} from 'react-native';
import color from '../../utills/Colors';
import {width, height} from 'react-native-dimension';
const styles = StyleSheet.create({
  tabBar: {
    flexDirection: 'row',
    width: width(100),
    height: height(8),
    alignItems: 'flex-start',
    backgroundColor: 'rgba(255, 255, 255, 0)',
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
    zIndex: 0,
  },
  tabBar1: {
    width: width(100),
    height: height(9),
    position: 'absolute',
    zIndex: 0,
    bottom: 0,
  },
  singleItemContainer: {
    marginTop: height(100) > 670 ? height(2) : height(2),
    justifyContent: 'center',
    alignItems: 'center',
  },
  logoContainer: {
    width: width(25),
    height: width(25),
  },
  logoContainer1: {
    width: width(25),
    height: width(25),
    marginTop: -height(7.5),
    marginLeft: width(1),
  },
});
export default styles;
