import React, {useEffect, useState} from 'react';
import {createBottomTabNavigator} from '@react-navigation/bottom-tabs';
import Message from '../../screens/Message/Message.screen';
import Social from './SocialStack';
import Dashboard from '../../screens/Dashboard/Dashboard.screen';
import Wallet from '../../screens/Wallet/Wallet.screen';
import Home from '../../screens/Home/Home.screen';
import {width, height, totalSize} from 'react-native-dimension';
import AntDesign from 'react-native-vector-icons/AntDesign';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import FontAwesome from 'react-native-vector-icons/FontAwesome';
import color from '../../utills/Colors';
import styles from './Tab.styles';
import Svg, {Path, G} from 'react-native-svg';
import {SafeAreaProvider} from 'react-native-safe-area-context';
const Tab = createBottomTabNavigator();
import {View, Text, TouchableOpacity, Image} from 'react-native';
import {Keyboard} from 'react-native';
import {SafeAreaView} from 'react-native';
import {useSelector} from 'react-redux';
import Colors from '../../utills/Colors';

function MyTabBar({state, descriptors, navigation}) {
  const theme = useSelector(state => state.Auth.theme);
  const [themeColor, setThemeColor] = useState(
    theme == 'dark' ? '#000' : Colors.white,
  );
  const [themeColor1, setThemeColor1] = useState(
    theme == 'dark' ? Colors.white : Colors.blue,
  );

  useEffect(() => {
    console.log(state.index);
    const i = state.index;
    if (i == 2) {
      setThemeColor(theme == 'dark' ? 'rgba(67, 67, 80,0.8)' : Colors.white);
      setThemeColor1(theme == 'dark' ? Colors.white : Colors.blue);
    } else {
      setThemeColor(Colors.white);
      setThemeColor1(Colors.blue);
    }
  }, [state.index, theme]);
  const [vis, setVis] = useState(true);
  const focusedOptions = descriptors[state.routes[state.index].key].options;
  // console.log(height(100))
  if (focusedOptions.tabBarVisible === false) {
    return null;
  }
  useEffect(() => {
    Keyboard.addListener('keyboardDidShow', () => {
      setVis(false);
    });
    Keyboard.addListener('keyboardDidHide', () => {
      setVis(true);
    });
    return () => {
      Keyboard.removeAllListeners();
    };
  }, []);
  if (vis)
    return (
      <>
        <Image
          source={require('../../Assets/giga.png')}
          style={[styles.tabBar1, theme == 'dark' && {tintColor: themeColor}]}
        />
        <View style={styles.tabBar}>
          {state.routes.map((route, index) => {
            const {options} = descriptors[route.key];
            const isFocused = state.index === index;

            const onPress = () => {
              const event = navigation.emit({
                type: 'tabPress',
                target: route.key,
                canPreventDefault: true,
              });

              if (!isFocused && !event.defaultPrevented) {
                navigation.navigate(route.name);
              }
            };

            const onLongPress = () => {
              navigation.emit({
                type: 'tabLongPress',
                target: route.key,
              });
            };

            return (
              <View
                testID={options.tabBarTestID}
                style={[
                  styles.singleItemContainer,
                  {width: index == 2 ? width(28) : width(18)},
                ]}>
                <>
                  {index == 0 && (
                    <TouchableOpacity
                      accessibilityRole="button"
                      accessibilityStates={isFocused ? ['selected'] : []}
                      accessibilityLabel={options.tabBarAccessibilityLabel}
                      onPress={onPress}
                      onLongPress={onLongPress}>
                      <AntDesign
                        name={isFocused ? 'appstore1' : 'appstore-o'}
                        size={isFocused ? 32 : 28}
                        color={themeColor1}
                      />
                    </TouchableOpacity>
                  )}
                  {index == 1 && (
                    <TouchableOpacity
                      accessibilityRole="button"
                      accessibilityStates={isFocused ? ['selected'] : []}
                      accessibilityLabel={options.tabBarAccessibilityLabel}
                      onPress={onPress}
                      onLongPress={onLongPress}>
                      <FontAwesome
                        name={isFocused ? 'user' : 'user-o'}
                        size={isFocused ? 32 : 28}
                        color={themeColor1}
                      />
                    </TouchableOpacity>
                  )}
                  {index == 2 && (
                    <TouchableOpacity
                      accessibilityRole="button"
                      accessibilityStates={isFocused ? ['selected'] : []}
                      accessibilityLabel={options.tabBarAccessibilityLabel}
                      onPress={onPress}
                      onLongPress={onLongPress}
                      style={[styles.logoContainer1]}>
                      <Image
                        style={[styles.logoContainer]}
                        source={require('../../Assets/logo.png')}
                      />
                    </TouchableOpacity>
                  )}
                  {index == 3 && (
                    <TouchableOpacity
                      accessibilityRole="button"
                      accessibilityStates={isFocused ? ['selected'] : []}
                      accessibilityLabel={options.tabBarAccessibilityLabel}
                      onPress={onPress}
                      onLongPress={onLongPress}>
                      <MaterialCommunityIcons
                        name={isFocused ? 'chat' : 'chat-outline'}
                        size={isFocused ? 32 : 28}
                        color={themeColor1}
                      />
                    </TouchableOpacity>
                  )}
                  {index == 4 && (
                    <TouchableOpacity
                      accessibilityRole="button"
                      accessibilityStates={isFocused ? ['selected'] : []}
                      accessibilityLabel={options.tabBarAccessibilityLabel}
                      onPress={onPress}
                      onLongPress={onLongPress}>
                      <MaterialCommunityIcons
                        name={isFocused ? 'wallet' : 'wallet-outline'}
                        size={isFocused ? 32 : 28}
                        color={themeColor1}
                      />
                    </TouchableOpacity>
                  )}
                </>
              </View>
            );
          })}
        </View>
        <SafeAreaView style={{backgroundColor: themeColor}} />
      </>
    );
  else return null;
}
/* =============================================================================
<HomeTab />
============================================================================= */
const HomeTab = () => {
  return (
    <Tab.Navigator
      initialRouteName="Dashboard"
      tabBar={props => <MyTabBar {...props} />}>
      <Tab.Screen name="Home" component={Home} />
      <Tab.Screen name="Social" component={Social} />
      <Tab.Screen name="Dashboard" component={Dashboard} />
      <Tab.Screen name="Message" component={Message} />
      <Tab.Screen name="Wallet" component={Wallet} />
    </Tab.Navigator>
  );
};

export default HomeTab;
