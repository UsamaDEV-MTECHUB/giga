import React, {Component, useState} from 'react';
import {View, Text, Image} from 'react-native';
import styles from './Dashboard.styles';
import Button from '../../components/Button/Button.component';
import {useSelector, useDispatch} from 'react-redux';
import Container from '../../components/Container/Container.component';
import NewsRender from '../../components/NewsRender/NewsRender.component';
import {login, logout, setDark, setLight} from '../../Redux/Actions/Auth';
import Colors from '../../utills/Colors';
import Ionicons from 'react-native-vector-icons/Ionicons';
import FontAwesome5 from 'react-native-vector-icons/FontAwesome5';
import Entypo from 'react-native-vector-icons/Entypo';
import {TouchableOpacity} from 'react-native';
import {height, width} from 'react-native-dimension';
import Svg, {Path, G} from 'react-native-svg';
import {FlatList} from 'react-native';
import dummyData from './dummyData';
import {Switch} from 'react-native';
import {ImageBackground} from 'react-native';
import {ScrollView} from 'react-native';

export default function Dashboard() {
  const theme = useSelector(state => state.Auth.theme);
  const themeColor = theme == 'light' ? Colors.white : '#000';
  const themeColor1 = theme != 'light' ? Colors.white : '#000';
  const themeColor2 = theme == 'light' ? '#000' : Colors.pink;
  const themeColor3 = theme == 'light' ? Colors.white : '#2b2b31';
  const dispatch = useDispatch();
  const [lightMode, setLightMode] = useState(true);
  const suggestionRender = ({item}) => {
    return (
      <View
        style={[
          styles.suggestionCont,
          {backgroundColor: theme == 'light' ? Colors.white : themeColor3},
        ]}>
        <Text style={[styles.suggestionText, {color: themeColor1}]}>
          "{item}"
        </Text>
      </View>
    );
  };
  const setTheme = val => {
    if (val) dispatch(setLight());
    else dispatch(setDark());
  };
  const renderData = item => {
    return (
      <NewsRender
        themeColor3={themeColor3}
        themeColor1={themeColor1}
        item={item}
      />
    );
  };
  var data = dummyData.data.filter((i, inde) => inde % 2 == 0);
  var data1 = dummyData.data.filter((i, inde) => inde % 2 != 0);
  return (
    <Container backColor={themeColor} backgroundColor={Colors.bluePrimary}>
      {theme == 'dark' && (
        <View style={styles.starCont}>
          <View style={styles.starCont1}>
            <Entypo name="star" color={Colors.white} size={width(1)} />
            <Entypo name="star" color={Colors.white} size={width(2.3)} />
            <Entypo name="star" color={Colors.white} size={width(1)} />
            <Entypo name="star" color={Colors.white} size={width(2)} />
            <Entypo name="star" color={Colors.white} size={width(2)} />
          </View>
          <View style={styles.starCont2}>
            <Entypo name="star" color={Colors.white} size={width(1)} />
            <Entypo name="star" color={Colors.white} size={width(1)} />
            <Entypo name="star" color={Colors.white} size={width(1)} />
            <Entypo name="star" color={Colors.white} size={width(2)} />
            <Entypo name="star" color={Colors.white} size={width(2)} />
          </View>
          <View style={styles.starCont3}>
            <Entypo name="star" color={Colors.white} size={width(1)} />
            <Entypo name="star" color={Colors.white} size={width(1)} />
            <Entypo name="star" color={Colors.white} size={width(1)} />
            <Entypo name="star" color={Colors.white} size={width(2)} />
            <Entypo name="star" color={Colors.white} size={width(2)} />
          </View>
        </View>
      )}
      <View style={styles.container}>
        <TouchableOpacity>
          <FontAwesome5
            name={'grip-lines'}
            color={Colors.white}
            size={width(5)}
            solid
          />
        </TouchableOpacity>
        <Text style={styles.headerText}>Good afternoon, Mario!</Text>
        <Switch
          value={theme == 'light' ? true : false}
          onValueChange={setTheme}
          style={{width: width(5)}}
        />
      </View>
      <View style={[styles.secendaryHeader]}>
        <ImageBackground
          source={require('../../Assets/giga.png')}
          imageStyle={[styles.imageStyle, {tintColor: themeColor}]}
          style={styles.imageBackground}>
          <View style={styles.margin}>
            <Text style={[styles.bold, {color: themeColor2}]}>SAT, 30 MAY</Text>
            <Text style={styles.normal}>4 Task Left</Text>
          </View>
          <View style={[styles.cloudCont, {backgroundColor: themeColor}]}>
            <View style={styles.dot} />
            <View style={styles.transform}>
              <Ionicons
                style={styles.moon}
                name="ios-moon"
                color={'#F7FF4D'}
                size={width(8)}
              />
              <Ionicons
                name={theme == 'light' ? 'cloud-outline' : 'cloudy-sharp'}
                color={theme == 'light' ? Colors.bluePrimary : Colors.white}
                size={width(8)}
              />
              <Text style={[styles.temp, {color: themeColor1}]}>26ºC</Text>
            </View>
          </View>
          <View style={styles.margin1}>
            <Text style={[styles.bold, {color: themeColor2}]}>
              Milan, Italy
            </Text>
            <Text style={styles.normal}>Team meeting</Text>
          </View>
        </ImageBackground>
      </View>
      <View style={[styles.suggestionView]}>
        <FlatList
          data={dummyData.suggestions}
          horizontal={true}
          contentContainerStyle={styles.suggestionFlatlist}
          showsHorizontalScrollIndicator={false}
          renderItem={suggestionRender}
        />
      </View>
      <ScrollView
        showsVerticalScrollIndicator={false}
        contentContainerStyle={{
          flexDirection: 'row',
          width: width(100),
          paddingHorizontal: width(5),
          paddingBottom: height(13),
          justifyContent: 'space-between',
        }}>
        <View>{data.map(renderData)}</View>
        <View>{data1.map(renderData)}</View>
      </ScrollView>
    </Container>
  );
}
