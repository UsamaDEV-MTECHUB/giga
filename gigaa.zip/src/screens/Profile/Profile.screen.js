import React, {useState} from 'react';
import {View, Text, FlatList, TouchableOpacity} from 'react-native';
import styles from './Profile.styles';
import Container from '../../components/Container/Container.component';
import RenderGigs from '../../components/RenderGigs/RenderGigs.component';
import SocialHeader from '../../components/SocialHeader/SocialHeader.component';
import Colors from '../../utills/Colors';
import ImagePicker from 'react-native-image-crop-picker';
import AntDesign from 'react-native-vector-icons/AntDesign';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import {height, width} from 'react-native-dimension';
import SelectModal from '../../components/SelectModal/SelectModal.component';
import LinearGradient from 'react-native-linear-gradient';
import data from './dummyData';
export default function Dashboard({navigation, route}) {
  const [options, setOptions] = useState(false);
  const {user, isRequest} = route.params;
  const renderSocialMedia = ({item}) => {
    return (
      <AntDesign
        key={item}
        name={item.icon}
        size={width(6)}
        color={item.color}
      />
    );
  };
  const renderGigs = ({item}) => {
    return <RenderGigs key={item} item={item} />;
  };
  return (
    <Container backColor={Colors.white} backgroundColor={Colors.bluePrimary}>
      <View
        style={{backgroundColor: Colors.bluePrimary, paddingBottom: height(8)}}>
        <SocialHeader
          back
          name={user.name}
          username={user.username}
          onMorePress={() => setOptions(true)}
          friends={123}
          // onFriendPress={() => navigation.navigate('Friends')}
          // onRequestPress={() => navigation.navigate('Requests')}
          gigs={17}
          image={{uri: user.image}}
        />
        {/* <View style={styles.buttonsCont}>
          <LinearGradient
            colors={['#715DFF', '#ba38aa', '#cb2f97', '#dd2681', '#FF155A']}
            start={{x: 0.0, y: 1.0}}
            end={{x: 1.0, y: 1.0}}
            style={styles.unfriendButton}>
            <TouchableOpacity
              style={{width: '100%', height: '100%', alignItems: 'center'}}>
              <Text style={styles.boldText}>Unfriend</Text>
            </TouchableOpacity>
          </LinearGradient>
          <TouchableOpacity style={styles.editCont}>
            <MaterialCommunityIcons
              name={'chat'}
              size={width(7)}
              color={Colors.white}
            />
            <Text style={styles.boldText}>Message</Text>
          </TouchableOpacity>
        </View> */}
        <View style={styles.socialMediaCont}>
          <FlatList
            horizontal={true}
            ItemSeparatorComponent={() => <View style={{width: width(2)}} />}
            renderItem={renderSocialMedia}
            data={data.socialMedia}
            keyExtractor={item => item}
            showsHorizontalScrollIndicator={false}
          />
        </View>
      </View>
      <LinearGradient
        style={styles.gigContainer}
        colors={[Colors.white, '#f0f0f0']}>
        <Text style={styles.boldTextBlue}>GIGs</Text>
        <FlatList
          contentContainerStyle={styles.gigFlatlist}
          ItemSeparatorComponent={() => <View style={{height: height(2)}} />}
          renderItem={renderGigs}
          data={data.gigs}
          keyExtractor={item => item}
          showsVerticalScrollIndicator={false}
        />
      </LinearGradient>
      <SelectModal
        visible={options}
        cancil="Cancel"
        firstOption="Share Profile"
        secondOption="Copy Profile URL"
        danger="Report"
        cancilPress={() => setOptions(false)}
      />
    </Container>
  );
}
