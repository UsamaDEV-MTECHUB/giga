import React, {useState} from 'react';
import {View, Text, TouchableOpacity} from 'react-native';
import styles from './Search.styles';
import AntDesign from 'react-native-vector-icons/AntDesign';
import FontAwesome from 'react-native-vector-icons/FontAwesome';
import Container from '../../components/Container/Container.component';
import {useSelector, useDispatch} from 'react-redux';
import {height, width} from 'react-native-dimension';
import Colors from '../../utills/Colors';
import {TextInput} from 'react-native';
import {FlatList} from 'react-native';
import dummyData from './dummyData';
import RenderGigs from '../../components/RenderGigs/RenderGigs.component';
import FriendsList from '../../components/FriendsList/FriendsList.component';
import {ScrollView} from 'react-native';
export default function Dashboard({navigation}) {
  const user = useSelector(state => state.Auth.user);
  const dispatch = useDispatch();
  const [searchTerm, setSearchTerm] = useState('');
  const [option, setOption] = useState(0);
  const [data, setData] = useState(null);
  const renderFriendList = ({item}) => {
    return <FriendsList item={item} />;
  };
  const renderGigs = ({item}) => {
    return <RenderGigs key={item} item={item} />;
  };
  return (
    <Container backgroundColor={Colors.white} barStyle="dark-content">
      <View style={styles.mainview}>
        <TouchableOpacity onPress={() => navigation.goBack()}>
          <AntDesign name="left" color={Colors.bluePrimary} size={width(7)} />
        </TouchableOpacity>
        <View style={styles.search}>
          <TextInput
            placeholder="Search GIGs or People"
            placeholderTextColor={Colors.gray}
            style={styles.searchInput}
            onBlur={() => setData({das: 'ads'})}
            onChangeText={setSearchTerm}
            value={searchTerm}
            returnKeyType="search"
          />
          {searchTerm.length > 0 && (
            <TouchableOpacity
              onPress={() => {
                setSearchTerm('');
                setData(null);
              }}>
              <AntDesign
                name="closecircle"
                color={Colors.gray}
                size={width(4)}
              />
            </TouchableOpacity>
          )}
        </View>
        <TouchableOpacity onPress={() => navigation.navigate('CreateGig')}>
          <AntDesign name="pluscircle" color={Colors.blue} size={width(7)} />
        </TouchableOpacity>
      </View>
      {!data ? (
        <View style={styles.suggestionCont}>
          {dummyData.suggestion.map(item => {
            return (
              <TouchableOpacity style={styles.suggestion}>
                <Text style={styles.suggestionText}>{item}</Text>
              </TouchableOpacity>
            );
          })}
        </View>
      ) : (
        <View style={styles.categoriesCont}>
          <TouchableOpacity
            onPress={() => setOption(0)}
            style={styles.categories}>
            <FontAwesome
              name={option == 0 ? 'circle' : 'circle-o'}
              color={option == 0 ? '#5300cf' : '#A8A8B996'}
              size={width(5)}
            />
            <Text style={styles.textCat}>All Results</Text>
          </TouchableOpacity>
          <TouchableOpacity
            onPress={() => setOption(1)}
            style={styles.categories}>
            <FontAwesome
              name={option == 1 ? 'circle' : 'circle-o'}
              color={option == 1 ? '#5300cf' : '#A8A8B996'}
              size={width(5)}
            />
            <Text style={styles.textCat}>GIGs</Text>
          </TouchableOpacity>
          <TouchableOpacity
            onPress={() => setOption(2)}
            style={styles.categories}>
            <FontAwesome
              name={option == 2 ? 'circle' : 'circle-o'}
              color={option == 2 ? '#5300cf' : '#A8A8B996'}
              size={width(5)}
            />
            <Text style={styles.textCat}>People</Text>
          </TouchableOpacity>
        </View>
      )}
      <ScrollView>
        {option != 1 && (
          <>
            <Text style={styles.boldTextBlue}>People</Text>
            <FlatList
              style={{alignSelf: 'center', paddingTop: height(1)}}
              ItemSeparatorComponent={() => (
                <View style={{height: height(2)}} />
              )}
              data={dummyData.friends}
              contentContainerStyle={option == 2 && styles.gigFlatlist}
              keyExtractor={item => item}
              showsVerticalScrollIndicator={false}
              renderItem={renderFriendList}
            />
          </>
        )}
        {option != 2 && (
          <>
            <Text style={styles.boldTextBlue}>
              {data ? 'GIGs' : 'Suggested GIGs'}
            </Text>
            <FlatList
              style={{alignSelf: 'center'}}
              contentContainerStyle={styles.gigFlatlist}
              ItemSeparatorComponent={() => (
                <View style={{height: height(2)}} />
              )}
              renderItem={renderGigs}
              data={dummyData.gigs}
              keyExtractor={item => item}
              showsVerticalScrollIndicator={false}
            />
          </>
        )}
      </ScrollView>
    </Container>
  );
}
