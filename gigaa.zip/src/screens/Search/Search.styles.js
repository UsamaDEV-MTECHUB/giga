import {StyleSheet} from 'react-native';
import Colors from '../../utills/Colors';
import {width, height, totalSize} from 'react-native-dimension';

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  search: {
    width: '80%',
    alignSelf: 'center',
    height: height(5),
    borderRadius: 25,
    borderColor: Colors.gray,
    borderWidth: 1,
    paddingHorizontal: width(5),
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  searchInput: {
    width: '90%',
    height: height(5),
  },
  text: {fontSize: width(4.3), color: '#000'},
  mainview: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    width: width(100),
    paddingHorizontal: width(5),
    marginTop: height(2),
  },
  headerText: {fontSize: width(5), fontWeight: 'bold', color: '#000'},
  gigFlatlist: {
    alignSelf: 'center',
    marginTop: height(2),
    paddingBottom: height(20),
  },
  boldTextBlue: {
    color: Colors.bluePrimary,
    fontSize: width(4.3),
    fontWeight: 'bold',
    textAlign: 'center',
    marginTop: height(1),
    width: width(100),
  },
  suggestionCont: {
    flexDirection: 'row',
    width: width(95),
    alignSelf: 'center',
    flexWrap: 'wrap',
  },
  categoriesCont: {
    flexDirection: 'row',
    width: width(75),
    justifyContent: 'space-between',
    alignItems: 'center',
    alignSelf: 'center',
    marginTop: height(2),
  },
  categories: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  suggestion: {
    paddingVertical: height(0.8),
    paddingHorizontal: width(2.5),
    borderRadius: 25,
    borderWidth: 1,
    borderColor: Colors.blue,
    marginTop: height(1),
    marginRight: width(1),
  },
  suggestionText: {
    fontSize: width(3.2),
    color: Colors.bluePrimary,
  },
  textCat: {
    fontSize: width(3.7),
    color: Colors.bluePrimary,
    marginLeft: width(2),
  },
});
export default styles;
