import React, { Component } from 'react';
import { View, Text } from 'react-native';
import styles from './Login.styles';
import Button from '../../components/Button/Button.component';
import { useDispatch,useSelector } from 'react-redux';
import { login, logout } from '../../Redux/Actions/Auth';
export default function Login() {
    const dispatch = useDispatch()
        return (
            <View style={styles.container}>
                <Text> Login</Text>
                <Button title="Login" onPress={() => dispatch(login({ userName: 'John Doe' }))} />
            </View>
        )
}