import {StyleSheet} from 'react-native';
import Colors from '../../utills/Colors';
import {width, height, totalSize} from 'react-native-dimension';

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  editCont: {
    width: width(92),
    alignSelf: 'center',
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 25,
    backgroundColor: Colors.purple,
    borderWidth: 1,
    borderColor: Colors.pink,
    marginTop: height(2),
    paddingVertical: height(1.2),
  },
  boldText: {
    color: Colors.white,
    fontSize: width(4.3),
    fontWeight: 'bold',
  },
  socialMediaCont: {
    width: width(92),
    alignSelf: 'center',
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 25,
    backgroundColor: Colors.purple,
    borderWidth: 1,
    borderColor: Colors.pink,
    marginTop: height(2),
    paddingVertical: height(0.2),
    paddingHorizontal: width(13),
  },
  plusCont: {
    width: width(5.5),
    height: width(5.5),
    borderRadius: width(3),
    position: 'absolute',
    right: width(5),
    backgroundColor: Colors.bluePrimary,
    justifyContent: 'center',
    alignItems: 'center',
  },
  gigContainer: {
    height: height(65),
    width: width(100),
    borderTopRightRadius: 30,
    borderTopLeftRadius: 30,
    marginTop: -height(5),
  },
  gigFlatlist: {
    alignSelf: 'center',
    marginTop: height(2),
    paddingBottom: height(20),
  },
  boldTextBlue: {
    color: Colors.bluePrimary,
    fontSize: width(4.3),
    fontWeight: 'bold',
    textAlign: 'center',
    marginVertical: height(1),
  },
});
export default styles;
