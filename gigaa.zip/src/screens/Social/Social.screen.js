import React, {useState} from 'react';
import {View, Text, FlatList, TouchableOpacity} from 'react-native';
import styles from './Social.styles';
import Container from '../../components/Container/Container.component';
import RenderGigs from '../../components/RenderGigs/RenderGigs.component';
import SocialHeader from '../../components/SocialHeader/SocialHeader.component';
import {useSelector, useDispatch} from 'react-redux';
import Colors from '../../utills/Colors';
import ImagePicker from 'react-native-image-crop-picker';
import AntDesign from 'react-native-vector-icons/AntDesign';
import {height, width} from 'react-native-dimension';
import SelectModal from '../../components/SelectModal/SelectModal.component';
import LinearGradient from 'react-native-linear-gradient';
import data from './dummyData';
const defaultImage =
  'https://images.unsplash.com/photo-1529626455594-4ff0802cfb7e?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=500&q=60';
export default function Dashboard({navigation}) {
  const [options, setOptions] = useState(false);
  const [image, setImage] = useState(defaultImage);
  const renderSocialMedia = ({item}) => {
    return (
      <AntDesign
        key={item}
        name={item.icon}
        size={width(6)}
        color={item.color}
      />
    );
  };
  const renderGigs = ({item}) => {
    return <RenderGigs key={item} item={item} />;
  };
  const openCamera = () => {
    ImagePicker.openCamera({
      width: 300,
      height: 400,
      cropping: true,
    }).then(image => {
      setOptions(false);
      setImage(image.path);
    });
  };
  const openPiker = () => {
    ImagePicker.openPicker({
      width: 300,
      height: 400,
      cropping: true,
    }).then(image => {
      setOptions(false);
      setImage(image.path);
    });
  };
  const deletePicture = () => {
    setOptions(false);
    setImage(defaultImage);
  };
  return (
    <Container backgroundColor={Colors.bluePrimary}>
      <View
        style={{backgroundColor: Colors.bluePrimary, paddingBottom: height(8)}}>
        <SocialHeader
          name="Justine Lockne"
          username="lockedmyheart"
          onMorePress={() => setOptions(true)}
          friends={123}
          onFriendPress={() => navigation.navigate('Friends')}
          onRequestPress={() => navigation.navigate('Requests')}
          gigs={17}
          image={{uri: image}}
          requests={3}
        />
        <TouchableOpacity style={styles.editCont}>
          <Text style={styles.boldText}>Edit Profile</Text>
        </TouchableOpacity>
        <View style={styles.socialMediaCont}>
          <FlatList
            horizontal={true}
            ItemSeparatorComponent={() => <View style={{width: width(2)}} />}
            renderItem={renderSocialMedia}
            data={data.socialMedia}
            keyExtractor={item => item}
            showsHorizontalScrollIndicator={false}
          />
          <TouchableOpacity style={styles.plusCont}>
            <AntDesign name={'plus'} size={width(4)} color={Colors.white} />
          </TouchableOpacity>
        </View>
      </View>
      <LinearGradient
        style={styles.gigContainer}
        colors={[Colors.white, '#f0f0f0']}>
        <Text style={styles.boldTextBlue}>GIGs</Text>
        <FlatList
          contentContainerStyle={styles.gigFlatlist}
          ItemSeparatorComponent={() => <View style={{height: height(2)}} />}
          renderItem={renderGigs}
          data={data.gigs}
          keyExtractor={item => item}
          showsVerticalScrollIndicator={false}
        />
      </LinearGradient>
      <SelectModal
        visible={options}
        cancil="Cancel"
        firstOption="Open Camera"
        secondOption="Choose from Library"
        danger="Remove Current Photo"
        firstPress={openCamera}
        dangerPress={deletePicture}
        secondPress={openPiker}
        cancilPress={() => setOptions(false)}
      />
    </Container>
  );
}
