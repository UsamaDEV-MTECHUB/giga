export default {
  temp: [
    {
      day: 'Saturday',
      weather: 'Cloudy',
      temp: '21°C',
    },
    {
      day: 'Sunday',
      weather: 'Cloudy',
      temp: '23°C',
    },
    {
      day: 'Monday',
      weather: 'Partly Cloudy',
      temp: '25°C',
    },
    {
      day: 'Tuesday',
      weather: 'Partly Cloudy',
      temp: '22°C',
    },
    {
      day: 'Wednesday',
      weather: 'Clear',
      temp: '20°C',
    },
    {
      day: 'Thursday',
      weather: 'Clear',
      temp: '20°C',
    },
    {
      day: 'Friday',
      weather: 'Cloudy',
      temp: '23°C',
    },
  ],
  days: ['Near me', 'Today', 'Tomorrow', 'Next Week'],
};
