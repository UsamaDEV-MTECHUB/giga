import React, {Component, createRef, useRef, useState} from 'react';
import {View, Text, TouchableOpacity, Image} from 'react-native';
import styles from './WeatherDetail.styles';
import Button from '../../components/Button/Button.component';
import Container from '../../components/Container/Container.component';
import {useSelector, useDispatch} from 'react-redux';
import {login, logout} from '../../Redux/Actions/Auth';
import Colors from '../../utills/Colors';
import AntDesign from 'react-native-vector-icons/AntDesign';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import Entypo from 'react-native-vector-icons/Entypo';
import LinearGradient from 'react-native-linear-gradient';
import {height, width} from 'react-native-dimension';
import {FlatList} from 'react-native';
import dummydata from './dummydata';
import {TextInput} from 'react-native';
import {KeyboardAwareScrollView} from 'react-native-keyboard-aware-scroll-view';
export default function Dashboard({navigation}) {
  const user = useSelector(state => state.Auth.user);
  const [mute, setMute] = useState(false);
  const [vis, setVis] = useState(false);
  const dispatch = useDispatch();
  const text = createRef(null);
  const renderDays = ({item}) => {
    return (
      <View style={styles.flatList}>
        <Text style={styles.day}>{item.day}</Text>
        <Text style={styles.type}>{item.weather}</Text>
        <View style={styles.cloud}>
          <Entypo
            name={item.weather == 'Clear' ? 'moon' : 'cloud'}
            color={item.weather == 'Clear' ? 'yellow' : Colors.white}
            size={width(6)}
          />
          <Text style={styles.temp}>{item.temp}</Text>
        </View>
      </View>
    );
  };
  return (
    <Container backColor={Colors.blue} backgroundColor={Colors.blue}>
      <KeyboardAwareScrollView style={{width: width(100)}}>
        <LinearGradient
          colors={[
            '#1BFFE667',
            '#1BFFE667',
            '#1BFFE667',
            '#1BFFE6',
            '#1BFFE6',
            '#1BFFE6',
          ]}
          start={{x: 0.0, y: 1.0}}
          end={{x: 1.0, y: 1.0}}
          style={styles.gradientBorder}>
          <TouchableOpacity
            style={styles.cross}
            activeOpacity={0.9}
            onPress={() => navigation.popToTop()}>
            <AntDesign name="close" color={Colors.white} size={width(5.5)} />
          </TouchableOpacity>
        </LinearGradient>
        <Text style={styles.boldText}>What can I help you with?</Text>
        <Text style={styles.lightText}>
          what’s the weather like this week in hamburg?
        </Text>
        <View style={styles.middleCont}>
          <Text style={styles.text}>Friday, 19 July</Text>
          <Text style={styles.largeText}>23°C</Text>
          <Text style={styles.smallText}>
            High {<Text style={styles.smallGray}>25°</Text>}
          </Text>
          <Text style={styles.smallText}>
            Low {<Text style={styles.smallGray}>20°</Text>}
          </Text>
          <Text style={styles.text}>Hamburg, Germany</Text>
          <Text style={styles.smallText}>Partly Cloudy %0</Text>
          <Text style={styles.smallGray}>%0 Precipitation</Text>
          <Text style={styles.smallGray}>5 km/h Wind </Text>
          <FlatList data={dummydata.temp} renderItem={renderDays} />
        </View>
        <View style={styles.container}>
          <FlatList
            data={dummydata.days}
            horizontal={true}
            style={styles.daysFlat}
            contentContainerStyle={{alignItems: 'flex-start'}}
            renderItem={({item}) => {
              return (
                <View style={styles.daysCont}>
                  <Text style={styles.days}>{item}</Text>
                </View>
              );
            }}
          />
        </View>
        <TextInput
          defaultValue="i want to buy a rain coat"
          ref={text}
          onFocus={() => setVis(true)}
          onBlur={() => setVis(false)}
          style={{color: Colors.white, alignSelf: 'center'}}
        />
      </KeyboardAwareScrollView>
      <View style={styles.bottom}>
        {vis ? (
          <View style={[styles.speaker, {backgroundColor: 'transparant'}]} />
        ) : (
          <TouchableOpacity
            style={styles.speaker}
            onPress={() => setMute(!mute)}>
            <MaterialCommunityIcons
              name={mute ? 'volume-off' : 'volume-high'}
              color={mute ? Colors.red : Colors.blue}
              size={width(6)}
            />
          </TouchableOpacity>
        )}
        <Image
          style={{
            width: width(25),
            height: width(25),
          }}
          source={require('../../Assets/logo.png')}
        />
        {vis ? (
          <TouchableOpacity style={styles.speaker}>
            <MaterialCommunityIcons
              name={'send'}
              color={Colors.blue}
              size={width(6)}
            />
          </TouchableOpacity>
        ) : (
          <TouchableOpacity
            onPress={() => text.current.focus()}
            style={styles.t}>
            <MaterialCommunityIcons
              name={'format-text'}
              color={Colors.white}
              size={width(6)}
            />
          </TouchableOpacity>
        )}
      </View>
    </Container>
  );
}
