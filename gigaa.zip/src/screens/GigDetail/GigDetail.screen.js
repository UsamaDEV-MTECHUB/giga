import React, {useState} from 'react';
import {Image} from 'react-native';
import {View, Text, ImageBackground} from 'react-native';
import {height, width} from 'react-native-dimension';
import LinearGradient from 'react-native-linear-gradient';
import Container from '../../components/Container/Container.component';
import Colors from '../../utills/Colors';
import styles from './GigDetail.Styles';
import Entypo from 'react-native-vector-icons/Entypo';
import AntDesign from 'react-native-vector-icons/AntDesign';
import SelectModal from '../../components/SelectModal/SelectModal.component';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import {TouchableOpacity} from 'react-native';
import {ScrollView} from 'react-native';
import Carousel from 'react-native-snap-carousel';
const GigDetail = ({navigation, route}) => {
  const {gig, request} = route.params;
  const [ownSelect, setOwnSelect] = useState(false);
  const [select, setSelect] = useState(false);
  const renderUserIcon = (image, index) => {
    if (index < 3)
      return (
        <Image
          source={{uri: image}}
          style={[styles.userImg, {marginLeft: index > 0 ? -width(5) : 0}]}
        />
      );
    else if (index == 3)
      return (
        <>
          <Image
            source={{uri: image}}
            style={[styles.userImg, {marginLeft: index > 0 ? -width(5) : 0}]}
          />
          <View style={styles.plusCont}>
            <Text style={styles.text}>{gig.users.length - 3}+</Text>
          </View>
        </>
      );
    else return <View />;
  };
  const setVisible = () => {
    if (gig.own) {
      setOwnSelect(true);
    } else {
      setSelect(true);
    }
  };
  const renderSnap = () => {
    return (
      <ImageBackground
        source={{uri: gig.image}}
        style={styles.imageBG}
        imageStyle={{borderRadius: 10}}>
        <View style={styles.topCont}>
          <View style={{flexDirection: 'row'}}>
            {gig.users.map(renderUserIcon)}
          </View>
          <Image source={{uri: gig.logo}} style={styles.image} />
        </View>
        <LinearGradient
          colors={['rgba(0,0,0,0.1)', 'rgba(0,0,0,0.2)', 'rgba(0,0,0,0.3)']}
          style={styles.bottonCont}>
          <View>
            <Text style={styles.boldText}>{gig.name}</Text>
            <Text style={styles.smallText}>
              {gig.date} @ {parseFloat(gig.price).toFixed(2)}
            </Text>
            <Text style={styles.smallText}>{gig.location}</Text>
          </View>
          {gig.own && (
            <TouchableOpacity
              onPress={() => navigation.navigate('EditGig', {gig: {...gig}})}
              activeOpacity={0.7}
              style={styles.gigType}>
              <MaterialCommunityIcons
                name="pencil"
                color={Colors.gray}
                size={width(5)}
              />
            </TouchableOpacity>
          )}
        </LinearGradient>
      </ImageBackground>
    );
  };
  return (
    <Container backgroundColor={Colors.white} barStyle="dark-content">
      <ScrollView
        showsVerticalScrollIndicator={false}
        contentContainerStyle={{paddingBottom: height(12)}}>
        <View style={styles.mainview}>
          <TouchableOpacity onPress={() => navigation.goBack()}>
            <AntDesign name="left" color={'#000000'} size={width(7)} />
          </TouchableOpacity>
          <Text style={styles.headerText}>ASOT 900 Live</Text>
          <TouchableOpacity onPress={() => navigation.popToTop()}>
            <TouchableOpacity onPress={setVisible}>
              <Entypo
                name="dots-three-vertical"
                color={'#000'}
                size={width(5)}
                solid
              />
            </TouchableOpacity>
          </TouchableOpacity>
        </View>
        <Carousel
          data={['asdsaf', 'fasfasf', 'fas']}
          loop={true}
          layout={'default'}
          renderItem={renderSnap}
          sliderWidth={width(100)}
          itemWidth={width(100)}
        />

        <View style={styles.center}>
          <Text style={styles.heading}>GIG Name</Text>
          <Text style={styles.det}>{gig.name}</Text>
          <Text style={styles.heading}>Location</Text>
          <Text style={styles.det}>{gig.location}</Text>
          <Text style={styles.heading}>When?</Text>
          <Text style={styles.det}>{gig.date}</Text>
          <Text style={styles.det}>{gig.date}</Text>
          <Text style={styles.heading}>Description</Text>
          <Text style={styles.det}>
            This is a mini party with small amounts of people. Who are
            quarantined and safe to be in the same place.
          </Text>
          <Text style={styles.heading}>Who is Coming? (Public Event)</Text>
          <Text style={styles.det}>1209 Participants</Text>
          <View style={styles.friends}>
            <View style={styles.friendList}>
              {gig.users.map((image, index) => {
                return (
                  <Image
                    source={{uri: image}}
                    style={[
                      styles.userImg1,
                      {marginLeft: index > 0 ? -width(8) : 0},
                    ]}
                  />
                );
              })}
            </View>
            <TouchableOpacity
              onPress={() => navigation.navigate('GigParticipants')}>
              <Text style={styles.showAll}>Show All</Text>
            </TouchableOpacity>
          </View>
        </View>
      </ScrollView>
      <SelectModal
        visible={ownSelect}
        cancil="Cancel"
        firstOption="Edit GIG"
        secondOption="Share"
        danger="Delete GIG"
        firstPress={() => {
          navigation.navigate('EditGig', {gig: {...gig}});
          setOwnSelect(false);
        }}
        cancilPress={() => setOwnSelect(false)}
      />
      <SelectModal
        visible={select}
        cancil="Cancel"
        firstOption="Join"
        secondOption="Share"
        danger="Report GIG"
        cancilPress={() => setSelect(false)}
      />
    </Container>
  );
};

export default GigDetail;
