import React, {Component, useState} from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  TextInput,
  ImageBackground,
  Image,
} from 'react-native';
import styles from './EditGig.styles';
import Button from '../../components/Button/Button.component';
import Container from '../../components/Container/Container.component';
import AntDesign from 'react-native-vector-icons/AntDesign';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import {useSelector, useDispatch} from 'react-redux';
import {login, logout} from '../../Redux/Actions/Auth';
import {width, height, totalSize} from 'react-native-dimension';
import DateTimePicker from '@react-native-community/datetimepicker';
import moment from 'moment';
import Colors from '../../utills/Colors';
import {KeyboardAwareScrollView} from 'react-native-keyboard-aware-scroll-view';
import LinearGradient from 'react-native-linear-gradient';
export default function Dashboard({navigation, route}) {
  const {gig, request} = route.params;
  const user = useSelector(state => state.Auth.user);
  const dispatch = useDispatch();
  const [isDate, setIsDate] = useState(false);
  const [isTime, setIsTime] = useState(false);
  const [state, setState] = useState({
    startDate: gig.date,
    endDate: gig.date,
    isStartDate: false,
    isEndDate: false,
    name: '',
    location: '',
    description: '',
    private: false,
    currentLocation: false,
    isPrivate: false,
  });
  var date = new Date();
  date.setDate(date.getDate() + 1);

  const renderUserIcon = (image, index) => {
    if (index < 3)
      return (
        <Image
          source={{uri: image}}
          style={[styles.userImg, {marginLeft: index > 0 ? -width(5) : 0}]}
        />
      );
    else if (index == 3)
      return (
        <>
          <Image
            source={{uri: image}}
            style={[styles.userImg, {marginLeft: index > 0 ? -width(5) : 0}]}
          />
          <View style={styles.plusCont}>
            <Text style={styles.text}>{gig.users.length - 3}+</Text>
          </View>
        </>
      );
    else return <View />;
  };
  const setDate = (event, date, key) => {
    setIsDate(false);
    setIsTime(true);
    setState(state => {
      return {
        ...state,
        [key]: moment(date).format('DD-MM-YYYY'),
      };
    });
  };
  const setTime = (event, date, key, key1) => {
    setIsTime(false);
    setState(state => {
      return {
        ...state,
        [key]: state[key] + ' ' + moment(date).format('hh-mm A'),
        [key1]: false,
      };
    });
  };
  const onChangeText = (key, value) => {
    setState(state => {
      return {
        ...state,
        [key]: value,
      };
    });
    if (key == 'isStartDate' || key == 'isEndDate') setIsDate(true);
  };
  return (
    <Container barStyle="dark-content" backgroundColor={Colors.white}>
      <KeyboardAwareScrollView
        contentContainerStyle={{paddingBottom: height(12)}}>
        <View style={styles.mainview}>
          <TouchableOpacity onPress={() => navigation.goBack()}>
            <AntDesign name="left" color={'#000000'} size={width(7)} />
          </TouchableOpacity>
          <Text style={styles.headerText}>Edit GIG</Text>
          <TouchableOpacity onPress={() => navigation.popToTop()}>
            <AntDesign
              name="close"
              color={Colors.bluePrimary}
              size={width(7)}
            />
          </TouchableOpacity>
        </View>
        <ImageBackground
          source={{uri: gig.image}}
          style={styles.imageBG}
          imageStyle={{borderRadius: 10}}>
          <View style={styles.topCont}>
            <View style={{flexDirection: 'row'}}>
              {gig.users.map(renderUserIcon)}
            </View>
            <Image source={{uri: gig.logo}} style={styles.image} />
          </View>
          <LinearGradient
            colors={['rgba(0,0,0,0.1)', 'rgba(0,0,0,0.2)', 'rgba(0,0,0,0.3)']}
            style={styles.bottonCont}>
            <View>
              <Text style={styles.boldText}>{gig.name}</Text>
              <Text style={styles.smallText}>
                {gig.date} @ {parseFloat(gig.price).toFixed(2)}
              </Text>
              <Text style={styles.smallText}>{gig.location}</Text>
            </View>
          </LinearGradient>
        </ImageBackground>
        <View style={styles.name}>
          <Text style={styles.text}>GIG Name</Text>
          <AntDesign name="star" color={Colors.red} size={width(2)} />
        </View>
        <TextInput
          placeholder="GIG Name"
          defaultValue={gig.name}
          onChangeText={val => onChangeText('name', val)}
          placeholderTextColor={Colors.gray}
          style={styles.search}
          returnKeyType="search"
        />
        <View style={styles.name}>
          <Text style={styles.text}>Location</Text>
          <AntDesign name="star" color={Colors.red} size={width(2)} />
        </View>
        <TouchableOpacity
          onPress={() =>
            onChangeText('currentLocation', !state.currentLocation)
          }
          style={styles.checkBoxCont}>
          <View style={styles.checkBox}>
            {state.currentLocation && (
              <AntDesign name="check" color={Colors.blue} size={width(4)} />
            )}
          </View>
          <Text style={styles.locationText}>Use My Current Location</Text>
        </TouchableOpacity>
        <View style={styles.search}>
          <Text>Frida Isol</Text>
          <AntDesign
            name="minus"
            style={styles.transform1}
            color={Colors.gray}
            size={height(3)}
          />
          <TextInput
            placeholder="Location"
            value={state.location}
            onChangeText={val => onChangeText('location', val)}
            placeholderTextColor={Colors.gray}
            style={{width: '80%', height: height(5), paddingVertical: 0}}
            returnKeyType="search"
          />
        </View>
        {state.currentLocation && (
          <Text style={styles.loc}>{gig.location}</Text>
        )}
        <View style={styles.name}>
          <Text style={styles.text}>Start Date</Text>
          <AntDesign name="star" color={Colors.red} size={width(2)} />
        </View>
        <TouchableOpacity
          onPress={() => onChangeText('isStartDate', true)}
          style={{alignSelf: 'center'}}>
          <TextInput
            placeholder="Start Date"
            editable={false}
            value={state.startDate}
            placeholderTextColor={Colors.gray}
            style={styles.date}
            returnKeyType="search"
          />
        </TouchableOpacity>
        <View style={styles.name}>
          <Text style={styles.text}>End Date</Text>
          <AntDesign name="star" color={Colors.red} size={width(2)} />
        </View>

        <TouchableOpacity
          onPress={() => onChangeText('isEndDate', true)}
          style={{alignSelf: 'center'}}>
          <TextInput
            placeholder="End Date"
            editable={false}
            value={state.endDate}
            placeholderTextColor={Colors.gray}
            style={styles.date}
            returnKeyType="search"
          />
        </TouchableOpacity>
        <View style={styles.name}>
          <Text style={styles.text}>Description</Text>
          <AntDesign name="star" color={Colors.red} size={width(2)} />
        </View>
        <TextInput
          placeholder="Description"
          defaultValue="This is a mini party with small amounts of people. Who are quarantined and safe to be in the same place."
          multiline={true}
          onChangeText={val => onChangeText('description', val)}
          placeholderTextColor={Colors.gray}
          style={styles.description}
          textAlignVertical={'top'}
          returnKeyType="search"
        />
        <TouchableOpacity
          onPress={() => onChangeText('isPrivate', !state.isPrivate)}
          style={styles.checkBoxCont}>
          <View style={styles.checkBox}>
            {state.isPrivate && (
              <AntDesign name="check" color={Colors.blue} size={width(4)} />
            )}
          </View>
          <Text style={styles.locationText}>Make Private</Text>
        </TouchableOpacity>
        <View style={styles.privateCont}>
          <AntDesign
            name="exclamationcircleo"
            color={Colors.gray}
            style={styles.transform}
            size={width(3.2)}
          />
          <Text style={styles.private}>
            Public - Everyone can see your GIG{'\n'}Private - Only invited
            people can see your GIG
          </Text>
        </View>
        <LinearGradient
          colors={['#6564dd', '#5e67c9', '#556bb0', '#4d7099']}
          start={{x: 0.0, y: 1.0}}
          end={{x: 1.0, y: 1.0}}
          style={styles.friend}>
          <TouchableOpacity>
            <Text style={styles.textfriend}>Save</Text>
          </TouchableOpacity>
        </LinearGradient>
        {isDate && (
          <DateTimePicker
            minimumDate={date}
            value={date}
            mode="date"
            is24Hour={true}
            display="spinner"
            onChange={(event, date) =>
              setDate(event, date, state.isStartDate ? 'startDate' : 'endDate')
            }
          />
        )}
        {isTime ? (
          <DateTimePicker
            minimumDate={date}
            value={date}
            mode={'time'}
            is24Hour={false}
            display="spinner"
            onChange={(event, date) =>
              setTime(
                event,
                date,
                state.isStartDate ? 'startDate' : 'endDate',
                state.isStartDate ? 'isStartDate' : 'isEndDate',
              )
            }
          />
        ) : null}
      </KeyboardAwareScrollView>
    </Container>
  );
}
