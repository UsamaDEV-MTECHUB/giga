import {StyleSheet} from 'react-native';
import Colors from '../../utills/Colors';
import {width, height, totalSize} from 'react-native-dimension';

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  search: {
    width: width(90),
    alignSelf: 'center',
    height: height(5),
    borderRadius: 25,
    borderColor: Colors.gray,
    marginTop: height(3),
    borderWidth: 1,
    paddingHorizontal: width(5),
  },
  text: {fontSize: width(4.3), color: '#000'},
  username: {fontSize: width(3.6), color: Colors.bluePrimary},
  mainview: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    width: width(100),
    paddingHorizontal: width(5),
    marginTop: height(2),
  },
  headerText: {fontSize: width(5), fontWeight: 'bold', color: '#000'},
});
export default styles;
