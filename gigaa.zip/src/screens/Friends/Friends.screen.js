import React, {Component} from 'react';
import {View, Text, TouchableOpacity, Image} from 'react-native';
import styles from './Friends.styles';
import Button from '../../components/Button/Button.component';
import AntDesign from 'react-native-vector-icons/AntDesign';
import Container from '../../components/Container/Container.component';
import FriendsList from '../../components/FriendsList/FriendsList.component';
import {useSelector, useDispatch} from 'react-redux';
import {height, width} from 'react-native-dimension';
import Colors from '../../utills/Colors';
import {TextInput} from 'react-native';
import {FlatList} from 'react-native';
import dummyData from './dummyData';
export default function Dashboard({navigation}) {
  const user = useSelector(state => state.Auth.user);
  const dispatch = useDispatch();
  const renderFriendList = ({item}) => {
    return <FriendsList item={item} />;
  };
  return (
    <Container backgroundColor={Colors.white} barStyle="dark-content">
      <View style={styles.mainview}>
        <TouchableOpacity onPress={() => navigation.goBack()}>
          <AntDesign name="left" color={'#000000'} size={width(7)} />
        </TouchableOpacity>
        <Text style={styles.headerText}>Friends</Text>
        <TouchableOpacity>
          <AntDesign name="close" color={Colors.bluePrimary} size={width(7)} />
        </TouchableOpacity>
      </View>
      <TextInput
        placeholder="Search for Name, Surname and Username"
        placeholderTextColor={Colors.gray}
        style={styles.search}
        returnKeyType="search"
      />

      <FlatList
        style={{alignSelf: 'center', paddingTop: height(3)}}
        contentContainerStyle={{paddingBottom: height(20)}}
        ItemSeparatorComponent={() => <View style={{height: height(2)}} />}
        data={dummyData}
        keyExtractor={item => item}
        showsVerticalScrollIndicator={false}
        renderItem={renderFriendList}
      />
    </Container>
  );
}
