export default [
  {
    name: 'Kelly Cruz',
    username: 'star_kellyJ',
    close: true,
    friend: true,
    image:
      'https://images.unsplash.com/photo-1504276048855-f3d60e69632f?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=500&q=60',
  },
  {
    name: 'Kelly Baxtor',
    username: 'baxtorkellybaxtor',
    friend: true,
    image:
      'https://images.unsplash.com/photo-1485199692108-c3b5069de6a0?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=500&q=60',
  },
  {
    name: 'Kelly Kim Kylie',
    username: 'kkkylie',
    friend: false,
    image:
      'https://images.unsplash.com/photo-1514315384763-ba401779410f?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=500&q=60',
  },
  {
    name: 'Kelly Cruz',
    username: 'star_kellyJ',
    close: true,
    friend: true,
    image:
      'https://images.unsplash.com/photo-1504276048855-f3d60e69632f?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=500&q=60',
  },
  {
    name: 'Kelly Baxtor',
    username: 'baxtorkellybaxtor',
    friend: true,
    image:
      'https://images.unsplash.com/photo-1485199692108-c3b5069de6a0?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=500&q=60',
  },
  {
    name: 'Kelly Kim Kylie',
    username: 'kkkylie',
    friend: false,
    image:
      'https://images.unsplash.com/photo-1514315384763-ba401779410f?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=500&q=60',
  },
  {
    name: 'Kelly Cruz',
    username: 'star_kellyJ',
    close: true,
    friend: true,
    image:
      'https://images.unsplash.com/photo-1504276048855-f3d60e69632f?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=500&q=60',
  },
  {
    name: 'Kelly Baxtor',
    username: 'baxtorkellybaxtor',
    friend: true,
    image:
      'https://images.unsplash.com/photo-1485199692108-c3b5069de6a0?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=500&q=60',
  },
  {
    name: 'Kelly Kim Kylie',
    username: 'kkkylie',
    friend: false,
    image:
      'https://images.unsplash.com/photo-1514315384763-ba401779410f?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=500&q=60',
  },
  {
    name: 'Kelly Cruz',
    username: 'star_kellyJ',
    close: true,
    friend: true,
    image:
      'https://images.unsplash.com/photo-1504276048855-f3d60e69632f?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=500&q=60',
  },
  {
    name: 'Kelly Baxtor',
    username: 'baxtorkellybaxtor',
    friend: true,
    image:
      'https://images.unsplash.com/photo-1485199692108-c3b5069de6a0?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=500&q=60',
  },
  {
    name: 'Kelly Kim Kylie',
    username: 'kkkylie',
    friend: false,
    image:
      'https://images.unsplash.com/photo-1514315384763-ba401779410f?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=500&q=60',
  },
];
