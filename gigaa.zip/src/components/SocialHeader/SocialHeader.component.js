import React from 'react';
import {View, Text, TouchableOpacity, Image} from 'react-native';
import styles from './SocialHeader.Styles';
import FontAwesome5 from 'react-native-vector-icons/FontAwesome5';
import Entypo from 'react-native-vector-icons/Entypo';
import Colors from '../../utills/Colors';
import {width} from 'react-native-dimension';
import {useNavigation} from '@react-navigation/native';

const Component = ({
  image,
  name,
  username,
  friends,
  gigs,
  requests,
  onDrawerPress,
  onFriendPress,
  onGigPress,
  onRequestPress,
  onSearchPress,
  onMorePress,
  back,
}) => {
  const navigation = useNavigation();
  return (
    <View style={styles.container}>
      <TouchableOpacity
        onPress={back ? () => navigation.goBack() : onDrawerPress}>
        <FontAwesome5
          name={back ? 'chevron-left' : 'grip-lines'}
          color={Colors.white}
          size={width(5)}
          solid
        />
      </TouchableOpacity>
      <View style={styles.imageCont}>
        <Image source={image} style={styles.image} />
        <View style={{width: width(38)}}>
          <Text style={styles.boldText}>{name}</Text>
          <Text style={styles.text}>{username}</Text>
          <View style={styles.flexRow}>
            <TouchableOpacity onPress={onFriendPress}>
              <Text style={styles.boldText}>{friends}</Text>
              <Text style={styles.text}>Friends</Text>
            </TouchableOpacity>
            <TouchableOpacity onPress={onGigPress}>
              <Text style={styles.boldText}>{gigs}</Text>
              <Text style={styles.text}>Gigs</Text>
            </TouchableOpacity>
            {requests ? (
              <TouchableOpacity onPress={onRequestPress}>
                <Text style={styles.boldText}>{requests}</Text>
                <Text style={styles.text}>Requests</Text>
              </TouchableOpacity>
            ) : (
              <View style={{width: width(11)}} />
            )}
          </View>
        </View>
      </View>
      <View style={styles.searchCont}>
        <TouchableOpacity onPress={() => navigation.navigate('Search')}>
          <FontAwesome5
            name="search"
            color={Colors.white}
            size={width(5)}
            solid
          />
        </TouchableOpacity>
        <TouchableOpacity onPress={onMorePress}>
          <Entypo
            name="dots-three-vertical"
            color={Colors.white}
            size={width(5)}
            solid
          />
        </TouchableOpacity>
      </View>
    </View>
  );
};

export default Component;
