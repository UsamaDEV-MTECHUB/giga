import {StyleSheet} from 'react-native';
import {height, width} from 'react-native-dimension';
import Colors from '../../utills/Colors';

const styles = StyleSheet.create({
  container: {
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    paddingHorizontal: width(4),
    flexDirection: 'row',
    paddingTop: height(1),
    width: width(100),
  },
  imageCont: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    width: width(67),
  },
  boldText: {
    color: Colors.white,
    fontSize: width(4.3),
    fontWeight: 'bold',
  },
  text: {
    color: Colors.white,
    fontSize: width(3.5),
  },
  image: {
    width: width(25),
    height: width(25),
    borderRadius: width(12.5),
    borderWidth: 2,
    borderColor: Colors.blue,
  },
  flexRow: {
    flexDirection: 'row',
    width: width(43),
    justifyContent: 'space-between',
    marginTop: height(1),
  },
  searchCont: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    width: width(13),
  },
});
export default styles;
