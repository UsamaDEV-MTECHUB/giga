import React from 'react';
import {View, Text, TouchableOpacity} from 'react-native';
import {height, width} from 'react-native-dimension';
import Modal from 'react-native-modal';
import Colors from '../../utills/Colors';
import styles from './SelectModal.Styles';

const Component = ({
  danger,
  dangerPress,
  firstOption,
  firstPress,
  secondOption,
  secondPress,
  cancil,
  cancilPress,
  visible,
}) => {
  return (
    <Modal
      onBackdropPress={cancilPress}
      onBackButtonPress={cancilPress}
      style={{justifyContent: 'flex-end'}}
      isVisible={visible}>
      <View style={{width: width(95), alignSelf: 'center'}}>
        <View style={styles.mainCont}>
          <TouchableOpacity
            onPress={dangerPress}
            activeOpacity={0.4}
            style={styles.buttonCont}>
            <Text style={styles.redText}>{danger}</Text>
          </TouchableOpacity>
          <View style={styles.line} />
          <TouchableOpacity
            onPress={firstPress}
            activeOpacity={0.4}
            style={styles.buttonCont}>
            <Text style={styles.blueText}>{firstOption}</Text>
          </TouchableOpacity>
          <View style={styles.line} />
          <TouchableOpacity
            onPress={secondPress}
            activeOpacity={0.4}
            style={styles.buttonCont}>
            <Text style={styles.blueText}>{secondOption}</Text>
          </TouchableOpacity>
        </View>
        <TouchableOpacity
          onPress={cancilPress}
          activeOpacity={0.7}
          style={styles.cancilCont}>
          <Text style={styles.blueText}>{cancil}</Text>
        </TouchableOpacity>
      </View>
    </Modal>
  );
};

export default Component;
