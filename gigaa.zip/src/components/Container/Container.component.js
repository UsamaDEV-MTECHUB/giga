import React, {Fragment} from 'react';
import {View, SafeAreaView, StatusBar} from 'react-native';
import Colors from '../../utills/Colors';
import styles from './Container.Styles';

const Component = ({backgroundColor, barStyle, children, backColor}) => {
  return (
    <Fragment>
      <SafeAreaView style={{backgroundColor: backgroundColor}} />
      <StatusBar
        backgroundColor={backgroundColor}
        barStyle={barStyle ? barStyle : 'light-content'}
      />
      <View
        style={[
          styles.container,
          {backgroundColor: backColor ? backColor : Colors.white},
        ]}>
        {children}
      </View>
    </Fragment>
  );
};

export default Component;
