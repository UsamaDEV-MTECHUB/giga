import {StyleSheet} from 'react-native';
import Colors from '../../utills/Colors';

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'flex-start',
    alignItems: 'flex-start',
  },
});
export default styles;
