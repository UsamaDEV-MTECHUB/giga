import {StyleSheet} from 'react-native';
import {height, width} from 'react-native-dimension';
import Colors from '../../utills/Colors';
const borderR = 25;
const styles = StyleSheet.create({
  mainCont: {
    marginVertical: height(2),
    backgroundColor: Colors.white,
    borderRadius: borderR,
    elevation: 7,
    shadowColor: 'black',
    width: width(43),
    shadowOpacity: 0.3,
    shadowOffset: {
      width: 5,
      height: 5,
    },
  },
  imgStyle: {borderRadius: borderR, width: width(43)},
  cont: {backgroundColor: 'rgba(0,0,0,0.3)', borderRadius: borderR},
  heading: {
    color: Colors.white,
    fontWeight: 'bold',
    fontSize: width(4),
  },
  subHeading: {color: Colors.white, fontSize: width(3.5)},
  subCont: {
    paddingHorizontal: '7%',
    marginTop: height(8),
    marginBottom: height(5.5),
  },
  newsHeading: {
    color: Colors.white,
    fontWeight: 'bold',
    fontSize: width(3),
  },
  newsLoac: {
    color: Colors.white,
    fontSize: width(2),
    marginTop: height(0.6),
  },
  loca: {width: '40%', height: height(4)},
  date: {
    color: Colors.white,
    fontSize: width(2.5),
    marginTop: height(0.6),
  },
  location: {
    color: Colors.white,
    fontSize: width(2.5),
    marginTop: height(0.6),
  },
  simpleCont: {
    width: '70%',
    paddingVertical: height(0.7),
    borderRadius: 25,
    borderColor: Colors.white,
    borderWidth: 1,
    marginTop: height(1.5),
    justifyContent: 'center',
    alignItems: 'center',
  },
  simple: {
    color: '#ACEA21',
    fontSize: width(3.7),
  },
  name: {
    color: '#000',
    fontSize: width(3),
    fontWeight: 'bold',
    width: '70%',
  },
  logo: {
    width: width(8),
    height: width(8),
    borderRadius: width(4),
    position: 'absolute',
    bottom: -height(7),
    alignSelf: 'center',
  },
  bottomCont: {
    paddingVertical: height(1.5),
    paddingHorizontal: '8%',
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  shareCont: {
    flexDirection: 'row',
    width: '25%',
    justifyContent: 'space-between',
  },
});
export default styles;
