import React from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  Image,
  ImageBackground,
} from 'react-native';
import Colors from '../../utills/Colors';
import LinearGradient from 'react-native-linear-gradient';
import styles from './NewsRender.Styles';
import {useNavigation} from '@react-navigation/native';
import Entypo from 'react-native-vector-icons/Entypo';
import FontAwesome from 'react-native-vector-icons/FontAwesome';
import {width, height} from 'react-native-dimension';
const Component = ({item, themeColor3, themeColor1, isRequest}) => {
  const navigation = useNavigation();
  return (
    <View
      style={[
        styles.mainCont,
        {
          backgroundColor: themeColor3,
        },
      ]}>
      <ImageBackground
        imageStyle={styles.imgStyle}
        source={{uri: item.image}}
        style={{width: width(43)}}>
        <View style={styles.cont}>
          <View style={{paddingHorizontal: '7%', marginTop: height(2)}}>
            {item.heading && <Text style={styles.heading}>{item.heading}</Text>}
            {item.subHeading && (
              <Text style={styles.subHeading}>{item.subHeading}</Text>
            )}
          </View>
          <View style={styles.subCont}>
            {item.newsHeading && (
              <Text style={styles.newsHeading}>{item.newsHeading}</Text>
            )}
            {item.newsLocation && (
              <Text style={styles.newsLoac}>{item.newsLocation}</Text>
            )}
            {item.supponser && (
              <Image source={{uri: item.supponser}} style={styles.loca} />
            )}
            {item.date && <Text style={styles.date}>{item.date}</Text>}
            {item.location && (
              <Text style={styles.location}>{item.location}</Text>
            )}
            {item.simple && (
              <View style={styles.simpleCont}>
                <Text style={styles.simple}>Sample</Text>
              </View>
            )}
            {item.logo && (
              <Image source={{uri: item.logo}} style={styles.logo} />
            )}
          </View>
        </View>
      </ImageBackground>
      <View style={styles.bottomCont}>
        <Text numberOfLines={1} style={[styles.name, {color: themeColor1}]}>
          {item.name}
        </Text>
        <View style={styles.shareCont}>
          <FontAwesome
            name="share-square-o"
            size={width(4)}
            color={themeColor1}
          />
          <Entypo
            name="dots-three-vertical"
            size={width(4)}
            color={themeColor1}
          />
        </View>
      </View>
    </View>
  );
};

export default Component;
