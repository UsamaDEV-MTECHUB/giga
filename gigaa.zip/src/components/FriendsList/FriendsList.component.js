import React from 'react';
import {View, Text, TouchableOpacity, Image} from 'react-native';
import Colors from '../../utills/Colors';
import LinearGradient from 'react-native-linear-gradient';
import styles from './FriendsList.Styles';
import {useNavigation} from '@react-navigation/native';
import AntDesign from 'react-native-vector-icons/AntDesign';
import {width} from 'react-native-dimension';
const Component = ({item, isRequest}) => {
  const navigation = useNavigation();
  return (
    <View style={styles.rowview}>
      <TouchableOpacity
        onPress={() =>
          navigation.navigate('Profile', {
            user: item,
            isRequest: isRequest ? true : false,
          })
        }
        style={styles.rowview2}>
        <Image source={{uri: item.image}} style={styles.imagecontainer} />
        <View style={styles.namecontainer}>
          <Text style={styles.text}>{item.name}</Text>
          <Text style={styles.username}>
            {item.username}
            {item.close && <Text style={{color: Colors.gray}}> • Friend</Text>}
          </Text>
        </View>
      </TouchableOpacity>
      {/* <TouchableOpacity style={styles.addfriend}><Text style={{color:"#ffffff",textAlign:'center',fontWeight:'bold',fontSize:width(4)}}>Add Friend</Text></TouchableOpacity> */}

      {!isRequest ? (
        item.friend ? (
          <LinearGradient
            colors={['#715DFF', '#5e67c9', '#5a6abd', '#4D7099']}
            start={{x: 0.0, y: 1.0}}
            end={{x: 1.0, y: 1.0}}
            style={styles.friend}>
            <TouchableOpacity>
              <Text style={styles.textfriend}>Add Friend</Text>
            </TouchableOpacity>
          </LinearGradient>
        ) : (
          <LinearGradient
            colors={[
              'rgba(113, 93, 255, 1)',
              'rgba(113, 93, 255, 1)',
              'rgba(255, 21, 90, 0.5)',
              'rgba(255, 21, 90, 0.7)',
              'rgba(255, 21, 90, 0.8)',
              Colors.red,
            ]}
            start={{x: 0.0, y: 1.0}}
            end={{x: 1.0, y: 1.0}}
            style={styles.gradientBorder}>
            <TouchableOpacity style={styles.unfriend}>
              <Text style={styles.textunfriend}>Unfriend</Text>
            </TouchableOpacity>
          </LinearGradient>
        )
      ) : (
        <View style={styles.requestCOnt}>
          <AntDesign name="close" size={width(7)} color={Colors.red} />
          <AntDesign name="check" size={width(7)} color={'#715DFF'} />
        </View>
      )}
    </View>
  );
};

export default Component;
