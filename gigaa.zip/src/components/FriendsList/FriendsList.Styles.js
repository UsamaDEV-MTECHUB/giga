import {StyleSheet} from 'react-native';
import {height, width} from 'react-native-dimension';
import Colors from '../../utills/Colors';

const styles = StyleSheet.create({
  rowview: {
    flexDirection: 'row',
    alignItems: 'center',
    width: width(90),
    justifyContent: 'space-between',
  },
  rowview2: {flexDirection: 'row', alignItems: 'center'},
  imagecontainer: {
    width: width(16),
    height: width(16),
    borderRadius: width(8),
  },
  namecontainer: {marginLeft: width(4)},
  addfriend: {
    width: width(30),
    height: width(10),
    marginRight: width(5),
    justifyContent: 'center',
    borderRadius: width(15),
    backgroundColor: '#6464DA',
    marginLeft: width(5),
  },
  unfriend: {
    width: width(29),
    paddingVertical: height(1.15),
    borderRadius: width(15),
    backgroundColor: Colors.white,
  },
  friend: {
    width: width(29),
    paddingVertical: height(1.15),
    borderRadius: width(15),
  },
  gradientBorder: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 1.2,
    paddingVertical: 1.2,
    borderRadius: width(15),
  },

  textunfriend: {
    color: Colors.red,
    textAlign: 'center',
    fontWeight: 'bold',
    fontSize: width(4),
  },
  textfriend: {
    color: Colors.white,
    textAlign: 'center',
    fontWeight: 'bold',
    fontSize: width(4),
  },
  requestCOnt: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    width: width(18),
  },
});
export default styles;
