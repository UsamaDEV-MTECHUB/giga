import {StyleSheet} from 'react-native';
import {height, width} from 'react-native-dimension';
import Colors from '../../utills/Colors';

const styles = StyleSheet.create({
  container: {
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 15,
    backgroundColor: Colors.green,
    width: '80%',
    alignSelf: 'center',
    paddingVertical: 10,
    margin: 8,
    shadowColor: '#000',
    shadowOffset: {width: 0, height: 2},
    shadowOpacity: 0.5,
    shadowRadius: 2,
    elevation: 2,
  },
  text: {
    color: Colors.white,
    fontSize: width(3.6),
  },
  userImg: {
    width: width(9),
    height: width(9),
    borderRadius: width(4.5),
  },
  plusCont: {
    width: width(9),
    height: width(9),
    borderRadius: 60,
    backgroundColor: 'rgba(0,0,0,0.5)',
    justifyContent: 'center',
    alignItems: 'center',
    position: 'absolute',
    right: 0,
  },
  topCont: {
    paddingTop: '3%',
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingHorizontal: '5%',
    width: '100%',
  },
  bottonCont: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingHorizontal: '5%',
    width: '100%',
    // alignItems: 'flex-end',
    borderBottomRightRadius: 10,
    borderBottomLeftRadius: 10,
    paddingVertical: '3%',
  },
  boldText: {
    color: Colors.white,
    fontSize: width(4.0),
    fontWeight: 'bold',
  },
  smallText: {
    color: Colors.white,
    fontSize: width(3.2),
  },
  imageBG: {
    width: width(92),
    height: height(26),
    justifyContent: 'space-between',
  },
  gigType: {
    alignSelf: 'flex-end',
    marginBottom: '3%',
    paddingHorizontal: width(5),
    paddingVertical: height(0.6),
    borderRadius: 30,
  },
  image: {width: width(9), height: width(9), borderRadius: width(4.5)},
  requestCOnt: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    width: width(18),
  },
  invited: {fontSize: width(3.8), color: Colors.bluePrimary},
  invitedCont: {
    width: width(90),
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: height(1),
  },
});
export default styles;
