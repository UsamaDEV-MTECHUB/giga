import React from 'react';
import {Image} from 'react-native';
import {View, Text, ImageBackground, TouchableOpacity} from 'react-native';
import {height, width} from 'react-native-dimension';
import LinearGradient from 'react-native-linear-gradient';
import Colors from '../../utills/Colors';
import styles from './RenderGigs.Styles';
import AntDesign from 'react-native-vector-icons/AntDesign';
import {useNavigation} from '@react-navigation/native';

const Component = ({item, request}) => {
  const navigation = useNavigation();
  const renderUserIcon = (image, index) => {
    if (index < 3)
      return (
        <Image
          source={{uri: image}}
          style={[styles.userImg, {marginLeft: index > 0 ? -width(5) : 0}]}
        />
      );
    else if (index == 3)
      return (
        <>
          <Image
            source={{uri: image}}
            style={[styles.userImg, {marginLeft: index > 0 ? -width(5) : 0}]}
          />
          <View style={styles.plusCont}>
            <Text style={styles.text}>{item.users.length - 3}+</Text>
          </View>
        </>
      );
    else return <View />;
  };
  return (
    <>
      <TouchableOpacity
        activeOpacity={0.9}
        onPress={() =>
          navigation.navigate('GigDetail', {gig: {...item}, request})
        }>
        <ImageBackground
          source={{uri: item.image}}
          style={styles.imageBG}
          imageStyle={{borderRadius: 10}}>
          <View style={styles.topCont}>
            <View style={{flexDirection: 'row'}}>
              {item.users.map(renderUserIcon)}
            </View>
            <Image source={{uri: item.logo}} style={styles.image} />
          </View>
          <LinearGradient
            colors={['rgba(0,0,0,0.1)', 'rgba(0,0,0,0.2)', 'rgba(0,0,0,0.3)']}
            style={styles.bottonCont}>
            <View>
              <Text style={styles.boldText}>{item.name}</Text>
              <Text style={styles.smallText}>
                {item.date} @ {parseFloat(item.price).toFixed(2)}
              </Text>
              <Text style={styles.smallText}>{item.location}</Text>
            </View>
            <View
              style={[
                styles.gigType,
                {
                  backgroundColor: request
                    ? Colors.bluePrimary
                    : item.own
                    ? Colors.green
                    : '#715dff',
                },
              ]}>
              <Text style={styles.text}>
                {request ? 'Invited' : item.own ? 'Your Gig' : 'Going'}
              </Text>
            </View>
          </LinearGradient>
        </ImageBackground>
      </TouchableOpacity>
      {request && (
        <View style={styles.invitedCont}>
          <Text style={styles.invited}>Invited by {item.initedBy}</Text>
          <View style={styles.requestCOnt}>
            <AntDesign name="close" size={width(7)} color={Colors.red} />
            <AntDesign name="check" size={width(7)} color={'#715DFF'} />
          </View>
        </View>
      )}
    </>
  );
};

export default Component;
