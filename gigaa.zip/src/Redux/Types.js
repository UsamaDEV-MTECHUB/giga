// Auth types
export const LOGIN = 'LOGIN';
export const LOGOUT = 'LOGOUT';
export const SETDARK = 'SETDARK';
export const SETLIGHT = 'SETLIGHT';
