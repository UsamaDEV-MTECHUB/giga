const Colors = {
  green: '#669e01',
  blue: '#4D7099',
  bluePrimary: '#47678D',
  white: '#ffffff',
  purple: '#35789f',
  pink: '#1BFFE6',
  gray: '#b0b8ce',
  green: '#0b9d88',
  red: '#FF155A',
};
export default Colors;
